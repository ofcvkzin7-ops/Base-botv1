package com.basebot.v1;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private TextView status, photoLabel;
    private EditText name, cpf, cep, birth;
    private boolean running = false;
    private String photoUri = "";

    private TextView text(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(Color.WHITE);
        return t;
    }
    private EditText field(String hint, String key) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setHint(hint); e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xFFB9B1C9);
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF9B5CFF));
        e.setText(prefs.getString(key, ""));
        return e;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); return b;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("basebot_local", MODE_PRIVATE);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 36, 28, 28);
        page.setBackgroundColor(0xFF171322);

        TextView title = text("🤖 BASE BOT V1", 26);
        title.setGravity(Gravity.CENTER);
        page.addView(title);
        TextView sub = text("Painel local • Android", 14);
        sub.setGravity(Gravity.CENTER); page.addView(sub);

        status = text("Status: DESLIGADO", 18);
        status.setPadding(0, 24, 0, 12); page.addView(status);
        Button toggle = button("LIGAR / DESLIGAR");
        page.addView(toggle);
        toggle.setOnClickListener(v -> {
            running = !running;
            status.setText("Status: " + (running ? "LIGADO (painel local)" : "DESLIGADO"));
            Toast.makeText(this, running ?
                "Painel ativado. A conexão real do WhatsApp ainda precisa ser configurada." :
                "Painel desativado.", Toast.LENGTH_LONG).show();
        });

        TextView heading = text("Cadastro autorizado", 20);
        heading.setPadding(0, 22, 0, 8); page.addView(heading);
        page.addView(text("Preencha apenas seus próprios dados ou dados de alguém que autorizou.", 13));
        name = field("Nome completo", "name"); page.addView(name);
        cpf = field("CPF", "cpf"); page.addView(cpf);
        cep = field("CEP", "cep"); page.addView(cep);
        birth = field("Data de nascimento", "birth"); page.addView(birth);

        Button pick = button("ESCOLHER FOTO");
        page.addView(pick);
        photoLabel = text(prefs.getString("photo", "").isEmpty() ?
                "Nenhuma foto selecionada" : "Foto selecionada", 13);
        page.addView(photoLabel);
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, 44);
        });

        Button save = button("SALVAR CADASTRO");
        page.addView(save);
        save.setOnClickListener(v -> {
            prefs.edit().putString("name", name.getText().toString())
                .putString("cpf", cpf.getText().toString())
                .putString("cep", cep.getText().toString())
                .putString("birth", birth.getText().toString())
                .putString("photo", photoUri).apply();
            Toast.makeText(this, "Cadastro salvo neste celular.", Toast.LENGTH_SHORT).show();
        });

        Button show = button("VER MEUS DADOS");
        page.addView(show);
        show.setOnClickListener(v -> {
            String c = prefs.getString("cpf", "");
            String masked = c.length() > 4 ? "•••.•••." + c.substring(Math.max(0,c.length()-4)) : "não informado";
            new AlertDialog.Builder(this).setTitle("Meu cadastro")
                .setMessage("Nome: " + prefs.getString("name","") +
                    "\nCPF: " + masked +
                    "\nCEP: " + prefs.getString("cep","") +
                    "\nNascimento: " + prefs.getString("birth","") +
                    "\nFoto: " + (prefs.getString("photo","").isEmpty() ? "não cadastrada" : "selecionada"))
                .setPositiveButton("OK", null).show();
        });

        Button erase = button("APAGAR MEUS DADOS");
        page.addView(erase);
        erase.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Apagar cadastro?")
            .setMessage("Isso remove os dados salvos localmente neste aplicativo.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Apagar", (d,w) -> {
                prefs.edit().clear().apply();
                name.setText(""); cpf.setText(""); cep.setText(""); birth.setText("");
                photoUri = ""; photoLabel.setText("Nenhuma foto selecionada");
                Toast.makeText(this, "Dados apagados.", Toast.LENGTH_SHORT).show();
            }).show());

        page.addView(text("\nIMPORTANTE: esta versão é apenas o painel local. Ela ainda NÃO conecta ao WhatsApp nem consulta dados externos.", 13));
        ScrollView scroll = new ScrollView(this); scroll.addView(page);
        setContentView(scroll);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 44 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) {}
            photoUri = uri.toString();
            photoLabel.setText("Foto selecionada");
        }
    }
}
