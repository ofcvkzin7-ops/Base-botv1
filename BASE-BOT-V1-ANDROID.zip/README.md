# BASE BOT V1 — projeto Android inicial

Este ZIP contém o **código-fonte** de um aplicativo Android com identidade BASE BOT V1 (tema escuro/roxo), painel LIGAR/DESLIGAR, cadastro local, seleção de foto, visualização com CPF mascarado e exclusão dos dados.

## Limitação importante
Este projeto ainda **não é um APK compilado** e o botão LIGAR/DESLIGAR controla somente o painel local. Ele **não conecta ao WhatsApp**. A automação real do WhatsApp exige integração separada, normalmente com a Plataforma oficial WhatsApp Business Cloud API e configuração de servidor/webhook. Não é correto prometer que o APK sozinho captura dados de pessoas ou consulta CPF.

## Como gerar o APK
1. Abra o projeto no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Escolha Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O APK de teste será gerado em `app/build/outputs/apk/debug/`.

O app salva os campos no armazenamento privado local do aplicativo. Use apenas dados próprios ou fornecidos com autorização. Não use este protótipo para guardar CPF real sem proteção adicional e avaliação de conformidade com a LGPD.
